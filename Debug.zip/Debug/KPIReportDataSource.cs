﻿using System;
using System.Data;
using System.Text;
using System.Web;
using Volvo.IT.VVI.VVIDataAccess;

namespace Volvo.IT.VVI.ClientTier.VVIDataSources
{
    public class KPIReportDataSource
    {
        #region Public methods

        string [] strDate = new string[2];
        DataSet dsList = new DataSet();

        /// <summary>
        /// 
        /// </summary>
        /// <param name="From"></param>
        /// <param name="To"></param>
        /// <returns></returns>
        public DataSet GetList(DateTime df, DateTime dt)
        {
            dsList = new DataSet();
            strDate = ConvertDateFormat(df, dt);
            dsList = KPIReportData.GetVendorCountDetails(strDate[0], strDate[1]);
            HttpContext.Current.Session.Add("SupplierList", dsList);

            return dsList;
        }
      
        /// <summary>
        /// 
        /// </summary>
        /// <param name="vendorCode"></param>
        /// <param name="FromDiv2"></param>
        /// <param name="ToDiv2"></param>
        /// <returns></returns>
        public DataSet GetVendorList(string vendor, DateTime df, DateTime dt)
        {
            strDate = ConvertDateFormat(df, dt);
            dsList = KPIReportData.GetVendorActiveFrequency(vendor.Trim().PadLeft(10, '0'), strDate[0], strDate[1]);
            HttpContext.Current.Session.Add("VendorList", dsList);

            return dsList;
        }
        
      
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dateFrom"></param>
        /// <param name="dateTo"></param>
        /// <returns></returns>
        public DataSet GetNewUserList(DateTime df, DateTime dt)
        {
            strDate = ConvertDateFormat(df, dt);
            dsList = LoginHistoryData.GetNewUserList(strDate[0], strDate[1]);
            HttpContext.Current.Session.Add("UserList", dsList);
            return dsList;
        }
  

        /// <summary>
        /// 
        /// </summary>
        /// <param name="month"></param>
        /// <param name="year"></param>
        /// <returns></returns>
        public DataSet GetFilteredNewUserList(string month,string year,string p1,string p2)
        {
            dsList = LoginHistoryData.GetFilteredNewUserList(month, year, p1, p2);
            HttpContext.Current.Session.Add("UserListPopup", dsList);
            return dsList;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dateFrom"></param>
        /// <param name="dateTo"></param>
        /// <returns></returns>
        public DataSet GetVVICountList(DateTime df, DateTime dt)
        {
            strDate = ConvertDateFormat(df, dt);
            dsList = KPIReportData.GetVVICountList(strDate[0], strDate[1]);
            HttpContext.Current.Session.Add("PageCountList", dsList);
            return dsList;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dateFrom"></param>
        /// <param name="dateTo"></param>
        /// <returns></returns>
        public string[] ConvertDateFormat(DateTime df, DateTime dt)
        {
            string [] strDates =new string[2];
            StringBuilder sbDate = new StringBuilder();
            if (df.Equals(DateTime.MinValue) && dt.Equals(DateTime.MinValue)) 
            {}
            else if (df.Equals(DateTime.MinValue) && !dt.Equals(DateTime.MinValue))
            {
                strDates[1] = dt.ToString("MM/dd/yyyy");
            }
            else if (!df.Equals(DateTime.MinValue) && dt.Equals(DateTime.MinValue))
            {
                strDates[0] = df.ToString("MM/dd/yyyy");
            }
            else
            {
                strDates[0] = df.ToString("MM/dd/yyyy");
                strDates[1] = dt.ToString("MM/dd/yyyy");
            }

            return strDates;
        }
        #endregion Public methods
    }
}
